# FinFlow360 – Create Invoice UI

Responsive invoice creation screen built with semantic HTML, Tailwind CSS utilities, and a separate custom stylesheet.

## Quick preview

Open `index.html` in a browser with an internet connection. This preview loads Tailwind through its CDN and loads `finflow360-invoice.css` locally.

## Production Tailwind build

The Tailwind CDN is used only for the quick preview. For deployment, install the project dependencies and compile Tailwind locally:

```bash
npm install
npm run build:css
```

Then replace the Tailwind CDN script in `index.html` with this stylesheet link:

```html
<link rel="stylesheet" href="dist/tailwind.css">
```

Keep the `finflow360-invoice.css` link after the compiled Tailwind stylesheet so the brand-specific component styles take precedence.

## JavaScript integration points

The markup is intentionally JavaScript-free. Suggested hooks:

- `#create-invoice-form` – validate and submit invoice data.
- `#save-draft-button` – save the current form as a draft.
- `#supporting-documents` – read selected files, show a file queue, validate file size/type, and implement drag-and-drop if required.
- `#issue-date` and `#due-date` – enforce date rules (for example, due date cannot precede issue date).

The file input accepts PDF, Word, Excel, JPG, and PNG file extensions. Enforce actual MIME type, file size, authorization, and upload security on the server as well; the HTML `accept` attribute is only a client-side hint.

## Brand palette

- Primary Blue: `#175CD3`
- Deep Blue: `#123B82`
- Pale Blue: `#EFF6FF`
- Canvas: `#F4F8FF`
